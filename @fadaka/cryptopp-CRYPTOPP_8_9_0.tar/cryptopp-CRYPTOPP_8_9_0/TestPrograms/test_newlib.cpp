#include <string>
int main(int argc, char* argv[])
{
#ifndef __NEWLIB__
    int x[-1];
#endif
    return 0;
}
