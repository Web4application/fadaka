# 🧑‍💻 Contributing to Fadaka

Thanks for your interest! Here's how to contribute effectively:

---

## 🔧 Dev Setup

### Blockchain Node
```bash
go run ./cmd/main.go
```

### Python Backend
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

### Wallet UI
```bash
bundle install
bundle exec jekyll serve
```

---

## 🧪 Smart Contract Tooling (Hardhat + OpenZeppelin)

```bash
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox
npx hardhat compile
npx hardhat run scripts/deploy.js --network localhost
```

For upgradeable contracts:
```bash
npm install @openzeppelin/contracts-upgradeable @openzeppelin/hardhat-upgrades
```

---

## ✅ Linting & Testing

```bash
gofmt -w .
staticcheck ./...

cd api && pytest
```

---

## 🧰 Dev Tools
- `gci`, `golangci-lint`, `nilaway`
- `husky` + `eslint` + `jest` for frontend/backend
