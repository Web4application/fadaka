$ pip install "hume[microphone]"
