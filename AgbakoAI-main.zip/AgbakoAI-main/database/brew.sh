cd path/to/your/project
python -m venv myenv
myenv\Scripts\activate
source myenv/bin/activate
pip install -r requirements.txt
