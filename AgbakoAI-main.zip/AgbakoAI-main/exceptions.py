class IndustryNotSupported(Exception):
    pass

class TaskNotSupported(Exception):
    pass
