pip install speechrecognition transformers pyttsx3 torch
