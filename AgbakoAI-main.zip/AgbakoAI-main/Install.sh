sudo apt install python3 python3-pip -y
pip install virtualenv
virtualenv env
source env/bin/activate
pip install -r requirements.txt
